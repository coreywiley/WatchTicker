module.exports = {
    clientId: "{CLIENT_ID}",
    domain: "{DOMAIN}"
  };